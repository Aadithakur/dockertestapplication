package com.docker.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com")
public class DockertestApplication {

	public static void main(String[] args) {
		SpringApplication.run(DockertestApplication.class, args);
	}

}
